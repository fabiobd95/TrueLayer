=============================================
TrueLayer Test
=============================================

This program was develop in NodeJS. 

So to run it you have to:

	-> Install Node
	-> Open cmd/shell
	-> Go to this project directory
	-> Write "node truelayer.js" and press Enter
	-> Follow the steps